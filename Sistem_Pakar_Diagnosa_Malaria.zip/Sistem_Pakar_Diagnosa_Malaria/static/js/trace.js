// rendering sederhana: tampilkan setiap langkah sebagai card, tangani dict/string
(function () {
  const container = document.getElementById("trace-flow");
  const rawDetails = document.getElementById("trace-raw");
  const btnVisual = document.getElementById("btn-visual");
  const btnRaw = document.getElementById("btn-raw");
  const trace = window.TRACE_DATA || [];

  function toArray(x){ return Array.isArray(x) ? x : (x ? [x] : []); }

  function safeText(v){
    if (v === null || v === undefined) return "-";
    if (typeof v === "object") return JSON.stringify(v);
    return String(v);
  }

  function renderStep(i, step){
    const el = document.createElement("div");
    el.className = "trace-step";

    const title = document.createElement("div");
    title.className = "trace-step-title";
    const ruleName = step.rule || step.name || step.rule_id || ("step " + (i+1));
    title.innerHTML = `<strong>${i+1}. ${ruleName}</strong>`;
    el.appendChild(title);

    // antecedents
    if (step.antecedents){
      const a = document.createElement("div");
      a.className = "trace-step-row";
      a.innerHTML = `<span class="label">Antecedents:</span> ${toArray(step.antecedents).map(s=>"<span class='pill'>"+safeText(s)+"</span>").join(" ")}`;
      el.appendChild(a);
    }

    // CF fields
    const cfKeys = ["antecedent_cf","combined_cf_before","combined_cf_after","rule_cf","inferred_cf"];
    cfKeys.forEach(k=>{
      if (k in step){
        const r = document.createElement("div");
        r.className = "trace-step-row";
        r.innerHTML = `<span class="label">${k.replace(/_/g,' ')}:</span> <span class="mono">${Number(step[k]).toFixed(4)}</span>`;
        el.appendChild(r);
      }
    });

    // conclusion
    if (step.conclusion){
      const c = document.createElement("div");
      c.className = "trace-step-row conclusion";
      c.innerHTML = `<span class="label">Conclusion:</span> <span class="pill pill-accent">${safeText(step.conclusion)}</span>`;
      el.appendChild(c);
    }

    return el;
  }

  function render(){
    container.innerHTML = "";
    if (!trace || trace.length === 0){
      container.innerHTML = "<div class='info'>Tidak ada trace untuk ditampilkan.</div>";
      return;
    }
    const flow = document.createElement("div");
    flow.className = "trace-flow-inner";
    trace.forEach((t,i)=>{
      // if string try parse to JSON
      let step = t;
      if (typeof t === "string"){
        try { step = JSON.parse(t.replace(/'/g, '"')); } catch(e){ step = {msg: t}; }
      }
      flow.appendChild(renderStep(i, step));
    });
    container.appendChild(flow);
  }

  // toolbar
  btnVisual.addEventListener("click", function(){
    container.style.display = "";
    rawDetails.style.display = "none";
    btnVisual.classList.add("active");
    btnRaw.classList.remove("active");
  });
  btnRaw.addEventListener("click", function(){
    container.style.display = "none";
    rawDetails.style.display = "";
    btnRaw.classList.add("active");
    btnVisual.classList.remove("active");
  });

  // initial
  render();
  // default to visual
  btnVisual.click();
}());